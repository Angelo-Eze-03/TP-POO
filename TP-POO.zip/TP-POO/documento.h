#ifndef DOCUMENTO_H
#define DOCUMENTO_H

#include "qlabel.h"
#include "qlabel.h"
#include <iostream>
#include <ctime>
#include <cstdlib>



class Documento
{
    private:
            //datos del Documento en si
            char* nombre;
            char* fechaNac;
            char* nacionalidad;
            char* estadoCivil;
            char* motivoViaje;
            char* tipo;       //tipo de persona(1:aldeano,4:revolucionario, etc)
            int duracionEstadia;
            char* paisResidencia;
            bool acompanantes;
            bool admisible;

            //cantidad de datos
            const int cantDatos = 2;//deberia ir entre los corchetes pero nose porque me tira error

            //Generadores de documentacion correcta
             const char* nombresC[2];
             const char* fechasNacC[2];
             const char* nacionalidadesC[2];
             const char* estadosCivilC[2];
             const char* tiposVisitaC[3];
             const char* motivosViajeC[2];
                   int duracionEstadiaC[5];
             const char* paisesResidenciaC[2];
            //Generadores de documentacion Incorrecta
            const char* nombresI[2];
            const char* fechasNacI[2];
            const char* nacionalidadesI[2];
            const char* estadosCivilI[2];
            const char* tiposVisitaI;
            const char* motivosViajeI[2];
                  int duracionEstadiaI[2];
            const char* paisesResidenciaI[2];
    public:
            Documento();
            char *getNombre() const;
            void setNombre(char *newNombre);
            char *getFechaNac() const;
            void setFechaNac(char *newFechaNac);
            char *getNacionalidad() const;
            void setNacionalidad(char *newNacionalidad);
            char *getEstadoCivil() const;
            void setEstadoCivil(char *newEstadoCivil);
            char *getMotivoViaje() const;
            void setMotivoViaje(char *newMotivoViaje);
            int getDuracionEstadia() const;
            void setDuracionEstadia(int newDuracionEstadia);
            char *getPaisResidencia() const;
            void setPaisResidencia(char *newPaisResidencia);

            friend std::ostream& operator<<(std::ostream& os, const Documento& documento);
            //Generador de datos correctos
            void setNacionalidadC();
            void setFechaNacC();
            void setTipoVisitaC();
            void setDuracionEstadiaC();
            //Generador de datos Incorrectos
            void setNacionalidadI();
            void setFechaNacI();
            void setTipoVisitaI();
            void setDuracionEstadiaI();

            void gnerarDocumento();





            void GenerarPersona(QLabel* label);
            bool getAcompanantes() const;
            void setAcompanantes(bool newAcompanantes);
            char *getTipo() const;
            void setTipo(char *newTipo);
            int getCantDatos() const;
};

#endif // DOCUMENTO_H
